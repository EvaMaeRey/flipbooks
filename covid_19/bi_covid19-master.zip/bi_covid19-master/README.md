# bi_covid19
Análisis de diferentes aspectos relacionados con la pandemia de Covid19
