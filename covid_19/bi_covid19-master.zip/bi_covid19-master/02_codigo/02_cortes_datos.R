### Definir texto que indique fecha y hora de corte de los datos en los subtitulos ----

subtitulo_lineas <- str_c("Cifras a las 18:30 hrs. del ", 
                          day(Sys.Date()), 
                          " de marzo de 2020 (CDMX)")

subtitulo_treemaps <-  str_c("Cifras a las 18:00 hrs. del ", 
                             day(Sys.Date()), 
                             " de marzo de 2020 (CDMX)")
